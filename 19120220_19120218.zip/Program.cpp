#include"Program.h"
#include"ConsoleWork.h"
#include"HeaderSytem.h"
#include"Screen.h"

void RunProgram()
{
	UserList userlist;
	Admin admin;
	createUserList(userlist);
	LoadUserList(userlist);
	startScreen();
}


