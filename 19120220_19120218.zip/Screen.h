#pragma once
#include "ConsoleWork.h"
#include "HeaderSytem.h"
void getPass(char pass[]);
void registerScreen();
void loginScreen();
void startScreen();