#include"Program.h"


int main()
{

	RunProgram();
}